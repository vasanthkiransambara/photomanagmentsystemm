Rules/Steps to contribute:

  1. Star the repository
  2. Create an issue stating the changes that you want to contribute
  3. Get approval and assigned to the issue
  4. Fork the repository
  5. Clone it to you local machine
  6. Make the required changes/addition
  7. Commit and push to your remote fork
  8. Raise a PR with appropriate description and screenshots
  9. Get your PR merged!
